---test trigger after insert into a_investit qui va augmenter somme_ramasse de projet 
----au meme temps il teste le trigger before insert à investit qui utilise la fonction verifier_But-atteint pour voir la possibilité de inserer 
SELECT insert  into a_investit (projet_id,type_investissement_id,investisseur_id,somme_invest)values('1','2','5','3000');

---aprés on test avec select * from projet;

