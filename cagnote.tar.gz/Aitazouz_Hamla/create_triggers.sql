--------------------------------------------------------------------------------------------------------------------
----- AFter insert to a_investit (ajouter un investissement) 
--------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION after_invest() RETURNS TRIGGER AS $$
	DECLARE
		somme decimal(12,2);
                pro_id int;
                som decimal(12,2);
                s   decimal(12,2);
	   BEGIN 
                select NEW.projet_id into pro_id from a_investit ;
                select NEW.somme_invest  into som from a_investit ;
                select  somme_ramasse into s from  projet where projet_id=pro_id;
  	   UPDATE projet SET somme_ramasse = s+som  where projet_id=pro_id; 
           RETURN new;     
	   END;
           

$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_after_invest  ON a_investit ;
CREATE TRIGGER trg_after_invest AFTER INSERT ON a_investit FOR EACH ROW
	 EXECUTE PROCEDURE after_invest() ;
--------------------------------------------------------------------------------------------------------------------
----- before insert to invessement 
--------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION before_invest() RETURNS TRIGGER AS $$
	DECLARE
		x integer ;
	BEGIN 
                select projet_id into x from projet where projet_id=old.projet_id;
		IF (verefier_But_atteint(x) = true) THEN
		RAISE NOTICE 'le But de la cagnotte est atteint';
		END IF;
                RAISE NOTICE 'la cagnotte est en cours '; 
		RETURN New;
	END;

$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_before_invest  ON a_investit ;
CREATE TRIGGER trg_before_invest BEFORE INSERT ON a_investit FOR EACH ROW
	 EXECUTE PROCEDURE before_invest() ;
--------------------------------------------------------------------------------------------------------------------
----- before insert to projet  
--------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION before_project() RETURNS TRIGGER AS $$
    BEGIN
        IF NEW.nom_projet IS NULL THEN
            RAISE EXCEPTION 'le nom de projet ne peut pas être NULL';
        END IF;
        IF NEW.date_debut IS NULL THEN
            RAISE EXCEPTION 'la date debut ne peux pas etre null';
        END IF;
         IF NEW.date_fin IS NULL THEN
            RAISE EXCEPTION 'la date fin  ne peux pas etre null';
        END IF;
         IF NEW.But IS NULL THEN
            RAISE EXCEPTION 'le but ne peux pas etre null';
        END IF;
        RETURN NEW;
    END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_before_project  ON projet ;
CREATE TRIGGER trg_before_project  BEFORE INSERT ON projet FOR EACH ROW 
     EXECUTE PROCEDURE  before_project();

