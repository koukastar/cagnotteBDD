---------------------------------------------------------------------------------------------------------------
-------------------------------- Inscription utilisateur
---------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION creer_compte_utilisateur(lePrenom VARCHAR(64), leNom VARCHAR(64), le_nom_utilisateur VARCHAR(64), motDePasse VARCHAR(128), LeEmail VARCHAR(128) ,type VARCHAR(64),titre VARCHAR(64)) RETURNS void AS $$	

	BEGIN
		INSERT INTO compte_utilisateur(prenom, nom, nom_utilisateur, mot_de_passe,email,type_user)  VALUES(lePrenom, leNom, le_nom_utilisateur, motDePasse, LeEmail,type);
                IF(type='initiateur') THEN
                 INSERT INTO initiateur(titre) Values (titre);
                 RAISE NOTICE 'L compte utilisateur de type initiateur (Prenom : % , Nom: % ) est crée',lePrenom,leNom;
                 ELSIF (type='investisseur') then
                 INSERT INTO investisseur(titre) values (titre);
                 RAISE NOTICE 'L compte utilisateur de type investisseur (Prenom : % , Nom: % ) est crée',lePrenom,leNom;
                 ELSE
                 RAISE NOTICE 'TYPE NON DEFINIS';
                END IF;
		
        END;

$$ LANGUAGE plpgsql;

---------------------------------------------------------------------------------------------------------------
-------------------------------- desinscription utilisateur
---------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION Desinscrire_utilisateur(id_user integer ) RETURNS VOID AS $$
	declare
          x varchar(64);	
        BEGIN
        select type_user into  x from compte_utilisateur where compte_utilisateur_id=id_user;	
	delete from compte_utilisateur where compte_utilisateur_id=id_user;
        IF(x='initiateur') THEN
        delete from initiateur where compte_utilisateur_id=id_user;
        ELSE
        delete from investisseur where compte_utilisateur_id=id_user;
        END IF;
	RAISE NOTICE 'L utilisateur : % a etait deinscrit',id_user;
						
        END;
$$  LANGUAGE plpgsql;

---------------------------------------------------------------------------------------------------------------
-------------------------------- creation projet
---------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION creer_projet(nomProjet VARCHAR(64), lOrganisation int, leinitiateur_id int, ladescription text, ladate_debut date,ladate_fin date,leBut decimal(12,2) ,lasomme_ramasse decimal(12,2),leprojet_status_id int, leintermidiare_id int) RETURNS void AS $$	

	BEGIN
	INSERT INTO projet (nom_projet,organisation_id,initiateur_id,description ,date_debut, date_fin, But,somme_ramasse ,projet_status_id,intermidiare_id ) 		
	VALUES(nomProjet, lOrganisation, leinitiateur_id, ladescription,ladate_debut, ladate_fin,  leBut,lasomme_ramasse,leprojet_status_id,leintermidiare_id);
	RAISE NOTICE 'le projet (nomProjet : % ) est crée',nomProjet;
        END;

$$ LANGUAGE plpgsql;
---------------------------------------------------------------------------------------------------------------
-------------------------------- calcule commission (10% de but)
---------------------------------------------------------------------------------------------------------------

CREATE FUNCTION calcule_commission(laSommeCagnotte decimal(12,2)) RETURNS decimal(12,2) AS $$
    BEGIN
    RETURN  laSommeCagnotte* 0.1;
    
    END;
$$  LANGUAGE plpgsql;
---------------------------------------------------------------------------------------------------------------
-------------------------------- verifier type invesstissement
---------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION verifier_type_invest(leIDtype_invest int,sommeDinvest decimal(12,2) ) RETURNS Boolean AS $$	
        DECLARE 
                x int;
                y int;
                o VARCHAR(64);
               
	BEGIN
       
        select val_min into x from type_investissement where leIDtype_invest=type_investissement_id;
	select val_max into y from type_investissement where leIDtype_invest=type_investissement_id;		
	select option_nom into o from type_investissement where leIDtype_invest=type_investissement_id;
        IF ((o ='investment_low_benifits') and(sommeDinvest>x ) and (sommeDinvest<y) )then 
        RETURN true;
        ELSE 
        RETURN false;
        END IF;
        IF ((o ='investment_medium_benifits') and (sommeDinvest>x) and (sommeDinvest< y) )then 
        RETURN true;
        ELSE 
        RETURN false;
        END IF;
        IF ((o ='investment_large_benifits') and (sommeDinvest> y)) then 
        RETURN true;
        ELSE 
        RETURN false;
        END IF;
        RAISE NOTICE 'Erreur type investissement';
        RETURN false;
        END;

$$ LANGUAGE plpgsql;
---------------------------------------------------------------------------------------------------------------
-------------------------------- creer investissement
---------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION creer_investissement(leprojet_id int, letype_investissement_id int, linvestisseur_id int, lasomme_invest decimal(12,2)) RETURNS void AS $$	 
	DECLARE 
                x decimal(12,2);
                y decimal(12,2);
        BEGIN
         
        IF (verifier_type_invest(letype_investissement_id,lasomme_invest)=true) then
        INSERT INTO a_investit( projet_id,type_investissement_id,investisseur_id,somme_invest)
        VALUES(leprojet_id, letype_investissement_id,linvestisseur_id ,lasomme_invest);
        select somme_ramasse into x from projet where projet_id=leprojet_id;
        y=x+lasomme_invest;
        UPDATE projet SET somme_ramasse = y WHERE projet_id=leprojet_id;		
	RAISE NOTICE 'linvestissement effectuer';
        ELSE
        RAISE NOTICE 'investissement non effectuer';
        END IF;
        END;

$$ LANGUAGE plpgsql;


---------------------------------------------------------------------------------------------------------------
-------------------------------- verifier_affectation_rembourssement  
---------------------------------------------------------------------------------------------------------------

CREATE FUNCTION verefier_date_limit(leProjet_id int,linvestissseur_id int) RETURNS Boolean AS $$
    DECLARE 
       dateLimit date;
       cd date;
       ts Timestamp;
       ps int;
       investis_id int;
       som_rem decimal(12,2);   
    BEGIN
    select date_fin into dateLimit from projet where leProjet_id=projet_id;
    select date into cd from date ;
    IF ((dateLimit=cd) and (verefier_But_atteint(leProjet_id)=false)) then
    SELECT investisseur_id into investis_id from a_investit where investisseur_id  =linvestissseur_id;
    SELECT somme_invest into som_rem from a_investit where projet_id=leProjet_id and investis_id=linvestissseur_id;             
    INSERT INTO remboursser (projet_id,investisseur_id ,somme_rembourssement) values (leProjet_id,investis_id,som_rem);
    RAISE NOTICE 'La date limite de projet est atteinte';
    RETURN true;
    else 
    RETURN false;
    END IF;
    END;
$$  LANGUAGE plpgsql;
---------------------------------------------------------------------------------------------------------------
-------------------------------- verifier But atteint
---------------------------------------------------------------------------------------------------------------

CREATE FUNCTION verefier_But_atteint(leProjet_id int) RETURNS Boolean AS $$
    DECLARE 
       sc decimal(12,2);
       Bt decimal(12,2);
       commiss decimal(12,2);
       inter_id int;
       ps int;
    BEGIN
    select somme_ramasse into sc from projet where leProjet_id=projet_id;
    select But into Bt from projet where leProjet_id=projet_id;
    select intermidiare_id into inter_id from projet where leProjet_id=projet_id;
    IF (sc=Bt) then
    Bt=Bt+Bt*0.1;
    INSERT INTO comissionner(intermidiare_id,projet_id,somme_commission) values(inter_id,leProjet_id,comiss);
    select projet_status_id into ps from projet_status where nom_status='cagnotte_fini_avec_succee';
    UPDATE est_decrit SET projet_status_id= ps WHERE id_Usager=leid_usager;
    RAISE NOTICE 'le But atteint et comission attribuer';
    RETURN true;
    else 
    RETURN false;
    END IF;
    END;
$$  LANGUAGE plpgsql;


