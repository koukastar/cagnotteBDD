--- inscription d'utilisateur
SELECT creer_compte_utilisateur('kahina','aitazouz','kouka','kahinata','kouka@gmail.com','investisseur','ETUDIANT');
SELECT creer_compte_utilisateur('louiza','hamla','loui','la122','louiza@gmail.com','initiateur','ETUDIANT');
SELECT * from compte_utilisateur;
SELECT * from initiateur;
SELECT * from investisseur;
--- desincription  d'utilisateur
SELECT Desinscrire_utilisateur('4');
SELECT * from compte_utilisateur;
SELECT * from initiateur;
SELECT * from investisseur;



