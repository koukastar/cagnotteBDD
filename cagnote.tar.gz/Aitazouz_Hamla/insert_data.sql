INSERT INTO compte_utilisateur (prenom, nom,nom_utilisateur, mot_de_passe, email,type_user )
VALUES
('Denis', 'Diderot', 'Denis75', 'Denis75', 'Denis75@gmail.com' ,'initiateur'),
('Jean-Jacques', 'Rousseau', 'Jean-Jacques2', 'Jean-Jacques2', 'Jean-Jacques2@gmail.com','initiateur' ),
('Yan', 'Jusrski', 'Yan3', 'Yan3', 'Yan3@gmail.com' ,'investisseur'),
('Sophie', 'Laplante', 'Sophie4', 'Sophie4', 'Sophie4@gmail.com','investisseur')
;

INSERT INTO intermidiare (intermidiare_id, prenom,nom)
VALUES
('1','Sophie', 'Laplante' )
;

INSERT INTO organisation (organisation_nom, details)
VALUES
('OpenData', 'start up'),
('Gameloft', 'boite informatique spécialisé dans la creation de jeux'),
('Geronimo', 'boite informatique, creation aplication')
;
INSERT INTO type_investissement(type_investissement_id,option_nom,option_description,val_min ,val_max)
VALUES
('1','investment_law_benifits','vous aurez des bénifices limités' ,'15','100'),
('2','investment_medium_benifits','vous aurez des bénifices moyennes' ,'100','500'),
('3','investment_large_benifits', 'vous aurez de large bénifices','500','3000')
;

INSERT INTO projet_status (nom_status)
VALUES
('cagnotte_cree'),
('cagnotte_commence'),
('cagnotte_fini_avec_succee')
;
INSERT INTO date (date)
VALUES
('2019-05-12')
;

INSERT INTO projet (nom_projet, organisation_id,initiateur_id,description, date_debut, date_fin, But, somme_ramasse,projet_status_id,intermidiare_id)
VALUES
('game', '2','1','game de Gameloft', '2019-04-28 ','2019-05-28 ','2000','10','1','1'),
('appli1', '3','1','application de Geronimo', '2019-01-01 ','2019-05-01 ','5000','3000','2','1'),
('appli2', '1','1','application de OpenData', '2019-02-01 ','2019-06-01 ','10000','100','3','1')
;

INSERT INTO commenter (projet_id,compte_utilisateur_id, message_text, temps_courant )
VALUES
( '1','2', 'commentaire1', '2019-04-28 23:00:00' ),
( '2','3', 'commentaire2', '2019-02-28 10:00:00' ),
( '3','1', 'commentaire3', '2019-04-28 10:00:00' )
;

INSERT INTO investisseur (projet_id, compte_utilisateur_id)
VALUES
('1','2' ),
('2','3' ),
('3','1')
;


INSERT INTO a_investit (projet_id,type_investissement_id,investisseur_id,somme_invest)
VALUES
('1','1','1','15' ),
('2','2','2', '100'),
('3','3','3', '589' )
;



INSERT INTO parametres (projet_id,date_fin, But, temps_courant)
VALUES
('1','2019-12-28','2000', '2019-04-28 23:00:00'),
('2' ,'2019-10-28','5000', '2019-02-28 10:00:00'),
('3','2019-11-28' ,'10000','2019-04-28 10:00:00')
;

INSERT INTO initiateur (titre, organisation_id, compte_utilisateur_id )
VALUES
('titre', '3','3' )
;    

INSERT INTO est_decrit (projet_id,projet_status_id,temps_courant)
VALUES
('1','1','2019-04-28 23:00:00'),
('2','2','2019-02-28 10:00:00'),
('3','3','2019-04-28 10:00:00')
;

INSERT INTO commissionner (intermidiare_id, projet_id,somme_commission )
VALUES
('1', '1', '20' ),
('1', '2', '30'),
('1', '3', '500')
;

INSERT INTO remboursser (investisseur_id, projet_id,somme_rembourssement )
VALUES
('1', '1', '10' ),
('2', '2', '20'),
('3', '3', '50')
;
