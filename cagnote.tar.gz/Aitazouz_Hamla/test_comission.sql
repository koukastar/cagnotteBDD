---test commission 
SELECT  verefier_But_atteint('2');
SELECT  * from commissionner ;
SELECT  verefier_But_atteint('1');
SELECT  * from commissionner ;


