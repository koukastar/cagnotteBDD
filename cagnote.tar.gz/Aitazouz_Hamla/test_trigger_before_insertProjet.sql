---test trigger after insert into a_investit qui va augmenter somme_ramasse de projet 
----au meme temps il teste le trigger before insert à investit qui utilise la fonction verifier_But-atteint pour voir la possibilité de inserer 
SELECT INSERT INTO projet (nom_projet, organisation_id,initiateur_id,description, date_debut, date_fin, But, somme_ramasse,projet_status_id,intermidiare_id)
VALUES
(NULL,'2','2','application yuka','2019-02-02','2019-05-05','1000','10','2','1');
