---test type investissement 

SELECT verifier_type_invest('2','2000');

--- test invesstissement 

--le premier non inserer et le 2 eme il insere probleme de vérification de type
SELECT creer_investissement('2', '1', '3','200');

SELECT creer_investissement('3', '2', '1','300');

SELECT  * from a_investit;