

le projet est une cagnotte sur un projet informatique
les fichiers test:

test_inscription pour tester la creation des comptes utilisateurs et méme la desincription
test comission :teste de la fonction qui lance la comission
test rembourssement:teste de la fonction qui lance le rembourssement
test investissement : teste la possibilité de faire un investissement