DROP TABLE IF EXISTS commenter;
DROP TABLE IF EXISTS equipe_projet;
DROP TABLE IF EXISTS a_investit;
DROP TABLE IF EXISTS investisseur  CASCADE;
DROP TABLE IF EXISTS organisation CASCADE ;
DROP TABLE IF EXISTS parametres;
DROP TABLE IF EXISTS initiateur;
DROP TABLE IF EXISTS projet CASCADE;
DROP TABLE IF EXISTS projet_status  CASCADE ;
DROP TABLE IF EXISTS projet_status_historique  CASCADE;
DROP TABLE IF EXISTS type_investissement  CASCADE ;
DROP TABLE IF EXISTS compte_utilisateur CASCADE ;
DROP TABLE IF EXISTS intermidiare  CASCADE;
DROP TABLE IF EXISTS commissionner ;
DROP TABLE IF EXISTS remboursser;
DROP TABLE IF EXISTS est_decrit;

CREATE TYPE status AS ENUM ('cagnotte_cree', 'cagnotte_commence', 'cagnotte_fini_avec_succee','cagnotte_fini_sans_succee');
CREATE TYPE nomInvest AS ENUM ('investment_low_benifits', 'investment_medium_benifits','investment_large_benifits'); 

CREATE TABLE Date (date DATE NOT NULL,
    PRIMARY KEY (date));


CREATE TABLE compte_utilisateur (
    compte_utilisateur_id  serial PRIMARY KEY ,
    prenom varchar(64)  NOT NULL,
    nom varchar(64)  NOT NULL,
    nom_utilisateur varchar(128)  NOT NULL  UNIQUE ,
    mot_de_passe varchar(255)  NOT NULL,
    email varchar(255) NOT NULL UNIQUE ,
    type_user varchar(64)
    
);
CREATE TABLE intermidiare (
    intermidiare_id int PRIMARY KEY ,
    prenom varchar(64)  NOT NULL,
    nom varchar(64)  NOT NULL
  
);

CREATE TABLE organisation (
    organisation_id serial PRIMARY KEY,
    organisation_nom varchar(255)  NOT NULL,
    details text  NULL
   
);

CREATE TABLE projet_status (
    projet_status_id serial PRIMARY KEY,
    nom_status status  NOT NULL  UNIQUE  
);

CREATE TABLE projet (
    projet_id serial PRIMARY KEY,
    nom_projet varchar(255)  NOT NULL UNIQUE ,
    organisation_id int REFERENCES organisation,
    initiateur_id int REFERENCES compte_utilisateur,
    description text  NOT NULL,
    date_debut date  NOT NULL,
    date_fin date  NOT NULL,
    But decimal(12,2)  NOT NULL CHECK (But>0),
    somme_ramasse decimal(12,2)  ,
    projet_status_id int REFERENCES  projet_status,
    intermidiare_id int  REFERENCES intermidiare,
    CHECK  (date_debut<date_fin)
    
);

CREATE TABLE commenter (
    projet_id int REFERENCES projet,
    compte_utilisateur_id int REFERENCES compte_utilisateur,
    PRIMARY KEY (projet_id,compte_utilisateur_id ),
    message_text text  NOT NULL,
    temps_courant timestamp  NOT NULL
);



CREATE TABLE type_investissement (
    type_investissement_id int PRIMARY KEY,
    option_nom varchar(255)  NOT NULL UNIQUE ,
    option_description text NOT NULL,
    val_min decimal(12,2)  NOT NULL CHECK (val_min>10) ,
    val_max decimal(12,2)  NOT NULL
    
    
);
CREATE TABLE investisseur (
    investisseur_id serial PRIMARY KEY ,
    projet_id int REFERENCES projet ,
    titre varchar(64),
    compte_utilisateur_id int REFERENCES compte_utilisateur
);

CREATE TABLE a_investit (
    projet_id int REFERENCES projet,
    type_investissement_id int REFERENCES type_investissement,
    investisseur_id int REFERENCES investisseur,
    somme_invest decimal(12,2)  NOT NULL ,
    PRIMARY KEY(projet_id,type_investissement_id,investisseur_id) 
);


CREATE TABLE parametres (
    parametres_id serial  PRIMARY KEY,
    projet_id int  REFERENCES projet ,
    date_fin date  NOT NULL,
    But decimal(12,2)  NOT NULL CHECK (But>0),
    temps_courant timestamp  NOT NULL
   
);

CREATE TABLE initiateur (
    initiateur_id serial  PRIMARY KEY ,
    titre varchar(64)  NOT NULL,
    organisation_id int  NULL,
    compte_utilisateur_id int REFERENCES compte_utilisateur 
);


CREATE TABLE est_decrit(
    projet_id int  REFERENCES  projet,
    projet_status_id int REFERENCES  projet_status,
    PRIMARY KEY(projet_id,projet_status_id),
    temps_courant timestamp  NOT NULL
    
);

CREATE TABLE commissionner (
    intermidiare_id int REFERENCES intermidiare,
    projet_id int REFERENCES projet,
    PRIMARY KEY (intermidiare_id, projet_id),
    somme_commission int not NULL  
);
CREATE TABLE remboursser (
    investisseur_id int REFERENCES investisseur,
    projet_id int REFERENCES projet,
    PRIMARY KEY ( investisseur_id, projet_id),
    somme_rembourssement int NOT NULL
      
);
CREATE INDEX index_But ON projet (But) ;
CREATE INDEX index_date_fin ON projet (date_fin) ;